window.Granim = require('./lib/Granim.js');
